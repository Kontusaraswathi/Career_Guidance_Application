from tkinter import*
from tkinter import messagebox
from random import*
from tkinter import Text
from tkinter import PhotoImage
import tkinter as tk
from PIL import Image,ImageTk
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from getpass import getpass
from gtts import*
from webbrowser import*
import webbrowser
import subprocess

# def open_python_shell():
#     subprocess.run(['python','ch.py'])

smtp_server = "smtp.gmail.com"
smtp_port = 587  
sender_email = "kontusaraswathi2007@gmail.com"
smtp_password = "hbscgohvzmhxvqgj"
subject="Your Career Path"
body="Thank you for using our application.ALL THE BEST FOR YOUR CAREER"
smtp_username="kontusaraswathi2007@gmail.com"
def email(sender_email, recipient_email, subject, body, image_path, smtp_server, smtp_port, smtp_username, smtp_password):
    # Create a MIME multipart message
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = subject

    # Attach text message
    msg.attach(MIMEText(body, 'plain'))

    # Attach image
    with open(image_path, 'rb') as img_file:
        image = MIMEImage(img_file.read(), name='image.jpg')
        msg.attach(image)

    # Connect to the SMTP server
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(smtp_username, smtp_password)

        # Send the email
        server.sendmail(sender_email, recipient_email, msg.as_string())
root=Tk()
root.geometry("1500x1500")
root.title("CAREER GUIDANCE APPLICATION")
# image_path=PhotoImage(Image.open("D:/bg.jpg"))
# bg_img=Label(image=image_path)
# bg_img.pack()
def welcome():
    global img,welcomeframe,image,photo
    welcomeframe=Frame(root,background='',width=1900,height=1200)
    welcomeframe.place(x=20,y=20)
    img= Image.open(r'D:/bgr1.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(welcomeframe,image=img).place(x=10,y=10)
    Label(welcomeframe,text='''             WELCOME TO CAREER GUIDANCE 
                    APPLICATION''',font=('Times 20 italic bold',50,'bold'),fg='black',bg="darkslategray1").place(y=300)
    Button(welcomeframe,text="NEXT-->",font=('monoco',40),fg='black',bg='aquamarine1',command=login).place(x=900,y=650)

def login():
    global loginframe,GOAL,img,MAIL
    name=StringVar()
    GOAL=StringVar()
    study=StringVar()
    MAIL=StringVar()
    welcomeframe.place_forget()
    loginframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    loginframe.place(x=0,y=0)
    img= Image.open(r'D:/bg11.jpg')
    img_T=img.resize((1600,1200),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(loginframe,image=img).place(x=0,y=0,relwidth=1,relheight=1)
    Label(loginframe,text="NAME",font=('monoco',30),fg='black',bg="lightskyblue1").place(x=200,y=200 )
    Entry(loginframe,text=name,font=('monoco',30),fg='black').place(x=400,y=200)
    Label(loginframe,text="STUDY",font=('monoco',30),fg='black',bg="lightskyblue1").place(x=200,y=300)
    Entry(loginframe,text=study,font=('monoco',30),fg='black').place(x=400,y=300)
    Label(loginframe, text = " GOAL ",font=('monoco',30),fg='black',bg="lightskyblue1").place(x=200,y=400) 
    Entry(loginframe,text=GOAL,font=('monoco',30),fg='black').place(x=400,y=400)
    # text=e.get()
    Label(loginframe,text="MAIL",font=('monoco',30),fg='black',bg="lightskyblue1").place(x=200,y=500)
    Entry(loginframe,text=MAIL,font=('monoco',30),fg='black').place(x=400,y=500)
    Button(loginframe,text="FIND YOUR CAREER PATH -->",font=('monoco',30),fg='black',bg='aqua',command=career).place(x=700,y=700)
    Button(loginframe,text="Do you want know your goal?",font=('monoco',30),fg='black',bg='aqua').place(x=100,y=700)
    
    recipient_email=MAIL.get()

def open_link(url):
    webbrowser.open(url)
# # link_label = Label(welcomeframe, text="Click to visit Google!", fg="blue", underline=True).place(x=400,y=600)
# Label("<Button-1>", lambda e: open_link("https://www.google.com"),fg="blue",underline=True).place(x=400,y=600)
def nextframe():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    im=Image.open(r'D:\Screenshot (264).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)
    img= Image.open(r'D:/bg11.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=software).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen',command=chat).place(x=50,y=650)
    
def doctor():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    text="https://www.youtube.com/watch?v=mu5WzOL8-O8&pp=ygUUaG93IHRvIGJlY29tZSBkb2N0b3I%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=mu5WzOL8-O8&pp=ygUUaG93IHRvIGJlY29tZSBkb2N0b3I%3D",font=('monoco',15),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=40,y=550)


def nextframe1():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background='',width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    im=Image.open(r'D:\Screenshot (266).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)
        # #email(sender_email, recipient_email, subject, 

        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=software).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen',command=chat).place(x=50,y=650)
    
def software():
    global doctorframe,img
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    text="https://www.youtube.com/watch?v=Fq4GSr5-Qbs&pp=ygUraG93IGNhbiBpIGJlY29tZSBzb2Z0d2FyZSAgZW5naW5lZXIgZW5nbGlzaA%3D%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=Fq4GSr5-Qbs&pp=ygUraG93IGNhbiBpIGJlY29tZSBzb2Z0d2FyZSAgZW5naW5lZXIgZW5nbGlzaA%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe1).place(x=40,y=550)


def nextframe2():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="antiquewhite3",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (265).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)

        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=software).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen').place(x=50,y=650)
def civil():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    text="https://www.youtube.com/watch?v=LCyZFTEyNoo&pp=ygUcaG93IHRvIGJlY29tZSBjaXZpbCBlbmdpbmVlcg%3D%3D"
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(doctorframe,text="https://www.youtube.com/watch?v=LCyZFTEyNoo&pp=ygUcaG93IHRvIGJlY29tZSBjaXZpbCBlbmdpbmVlcg%3D%3D",font=('monoco',15),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300) 
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe2).place(x=40,y=550)




def nextframe3():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img1= Image.open(r'D:/bgr2.jpg')
    img_T1=img1.resize((1600,1000),Image.LANCZOS)
    img1=ImageTk.PhotoImage(img_T1)
    Label(nextframe_doc,image=img1).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (289).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)

        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=teacher).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen',command=chat).place(x=50,y=650)
def teacher():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)

    text="https://www.youtube.com/watch?v=PKS_trfUXD4&pp=ygUgaG93IGNhbiBpIGJlY29tZSB0ZWFjaGVyIGVuZ2xpc2g%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=PKS_trfUXD4&pp=ygUgaG93IGNhbiBpIGJlY29tZSB0ZWFjaGVyIGVuZ2xpc2g%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe3).place(x=40,y=550)


def nextframe4():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="antiquewhite3",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (267).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)

        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=ai).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen',command=chat).place(x=50,y=650)

def ai():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe4).place(x=40,y=550)
    text="https://www.youtube.com/watch?v=J-nURWdlP_o&pp=ygUbaG93IHRvIGJlY29tZSBhaSBkZXZlbG9wZXIg"
    Button(doctorframe,text="https://www.youtube.com/watch?v=J-nURWdlP_o&pp=ygUbaG93IHRvIGJlY29tZSBhaSBkZXZlbG9wZXIg",font=('monoco',30),fg='black',bg="aquamarine1",command=open_link(text)).place(x=350,y=300)

def lawyer():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe4).place(x=40,y=550)
    text="https://www.youtube.com/watch?v=t9eTmptba78&pp=ygUXaG93IGNhbiBpIGJlY29tZSBsYXd5ZXI%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=t9eTmptba78&pp=ygUXaG93IGNhbiBpIGJlY29tZSBsYXd5ZXI%3D",font=('monoco',30),fg='black',bg="aquamarine1",command=open_link(text)).place(x=350,y=300)


def nextframe5():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="antiquewhite3",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (290).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)
    
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=lawyer).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen',command=chat).place(x=50,y=650)
# def law():
#     global doctorframe
#     doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
#     doctorframe.place(x=100,y=10)
#     Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe5).place(x=40,y=550)
#     text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D"
#     Button(doctorframe,text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)

def data():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe4).place(x=40,y=550)
    text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)


def nextframe6():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="antiquewhite3",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (274).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=ias).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen').place(x=50,y=650)
def ias():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe6).place(x=40,y=550)
    text="https://www.youtube.com/watch?v=IlqwHRVPCK8&pp=ygUUaG93IGNhbiBpIGJlY29tZSBpYXM%3D"
    Button(doctorframe,text="https://www.youtube.com/watch?v=IlqwHRVPCK8&pp=ygUUaG93IGNhbiBpIGJlY29tZSBpYXM%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=350,y=300)


def nextframe7():
    global nextframe_doc,im,img
    nextframe_doc=Frame(root,background="antiquewhite3",width=1500,height=1200)
    nextframe_doc.place(x=10,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(nextframe_doc,image=img).place(x=10,y=10)
    
    im=Image.open(r'D:\Screenshot (272).png')
    im_T=im.resize((600,600),Image.LANCZOS)
    im=ImageTk.PhotoImage(im_T)
    Label(nextframe_doc,image=im).place(x=500,y=20)
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
    Button(nextframe_doc,text="Click here to see a reference video-->",font=('monoco',30),fg='white',bg='forestgreen',command=army).place(x=700,y=650)
    Button(nextframe_doc,text="Do you have any queries?",font=('monoco',30),fg='white',bg='forestgreen').place(x=50,y=650)
def army():
    global doctorframe
    doctorframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    doctorframe.place(x=100,y=10)
    img= Image.open(r'D:/bgr2.jpg')
    img_T=img.resize((1600,1000),Image.LANCZOS)
    img=ImageTk.PhotoImage(img_T)
    Label(doctorframe,image=img).place(x=10,y=10)
    
    Button(doctorframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe7).place(x=40,y=550)
    text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D"
    Button(careerframe,text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D").place(x=400,y=700)

# im=Image.open(r'D:\Screenshot (272).png')
#         im_T=im.resize((650,550),Image.LANCZOS)
#         im=ImageTk.PhotoImage(im_T)
#         Label(careerframe,image=im).place(x=20,y=120)
#         Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
#         text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D"
#         Button(careerframe,text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D").place(x=400,y=700)

def career():
    global careerframe,img,im,img1
        
    if GOAL.get().lower()=="doctor" or GOAL.get().lower()=="mbbs" :
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/mbbs.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    
    elif GOAL.get().lower()=="civil engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/CIVIL.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        # im=Image.open(r'D:\Screenshot (265).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        # text="https://www.youtube.com/watch?v=LCyZFTEyNoo&pp=ygUcaG93IHRvIGJlY29tZSBjaXZpbCBlbmdpbmVlcg%3D%3D"
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        # Button(careerframe,text="https://www.youtube.com/watch?v=LCyZFTEyNoo&pp=ygUcaG93IHRvIGJlY29tZSBjaXZpbCBlbmdpbmVlcg%3D%3D",font=('monoco',15),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=400,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe2).place(x=1000,y=700)
        

    elif GOAL.get().lower()=="software engineer" or GOAL.get().lower()=="software":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/SOFTWARE.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe1).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="teacher":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        
        # im=Image.open(r'D:\Screenshot (264).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe3).place(x=1000,y=700)
        

    elif GOAL.get().lower()=="government job":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
    
        img=Image.open(r'')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        
        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)


    elif GOAL.get().lower()=="lawyer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/lawyer.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img1).place(x=100,y=100)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe5).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="cyber security engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
    
        img=Image.open(r'D:/cyber.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        
        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        text="https://www.youtube.com/watch?v=shgKU-zjOmw&pp=ygUlaG93IHRvIGJlY29tZSBjeWJlciBzZWN1cml0eSBlbmdpbmVlcg%3D%3D"
        Label(careerframe,text="https://www.youtube.com/watch?v=shgKU-zjOmw&pp=ygUlaG93IHRvIGJlY29tZSBjeWJlciBzZWN1cml0eSBlbmdpbmVlcg%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=400,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="data scientist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img1).place(x=10,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        
        img=Image.open(r'D:/data scientist.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        
        # im=Image.open(r'D:\Screenshot (273).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        # text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D"
        # Label(careerframe,text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUcaG93IHRvIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=400,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe5).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="chemical engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
    
        img=Image.open(r'D:/chemical_engineer.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (268).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Label(careerframe,text="https://www.youtube.com/watch?v=jtn-hRJjl68&pp=ygUfaG93IGNhbiBpIGJlY29tZSBkYXRhIHNjaWVudGlzdA%3D%3D",font=('monoco',30),fg='black',bg="aquamarine1").place(x=400,y=700)

    elif GOAL.get().lower()=="mechanical engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/mechanical.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (270).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)


    elif GOAL.get().lower()=="automobile engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="aerospace engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
    elif GOAL.get().lower()=="environmental engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T)
        Label(nextframe_doc,image=img).place(x=10,y=10)
    
        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
    elif GOAL.get().lower()=="ai developer" or GOAL.get().lower()=="ai engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img1= Image.open(r'D:/bgr2.jpg')
        img_T1=img1.resize((1600,1000),Image.LANCZOS)
        img1=ImageTk.PhotoImage(img_T1)
        Label(careerframe,image=img1).place(x=10,y=10)
    
        img=Image.open(r'D:/AI.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        # im=Image.open(r'D:\Screenshot (267).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe4).place(x=1000,y=700)
        

    elif GOAL.get().lower()=="ias":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/IAS.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        # im=Image.open(r'D:\Screenshot (274).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        # #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        # text="https://www.youtube.com/watch?v=IlqwHRVPCK8&pp=ygUUaG93IGNhbiBpIGJlY29tZSBpYXM%3D"
        # Button(careerframe,text="https://www.youtube.com/watch?v=IlqwHRVPCK8&pp=ygUUaG93IGNhbiBpIGJlY29tZSBpYXM%3D",font=('monoco',30),fg='black',bg="aquamarine1",COMMAND=open_link(text)).place(x=400,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="marine engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="mining engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
    elif GOAL.get().lower()=="ips":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )
        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="ifs":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="irs":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="iot developer" or GOAL.get().lower()=="iot engineer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (269).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="mbbs":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        

        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="nursing":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="physiotheraphy":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="pharmasist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="homeopathy doctor":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="researcher":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="scientist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()== "army" or "military":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/army.jpg')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        # im=Image.open(r'D:\Screenshot (272).png')
        # im_T=im.resize((650,550),Image.LANCZOS)
        # im=ImageTk.PhotoImage(im_T)
        # Label(careerframe,image=im).place(x=20,y=120)
        # Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        # text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D"
        # Button(careerframe,text="https://www.youtube.com/watch?v=Kbam2dBPWVo&pp=ygUaaG93IHRvIGJlY29tZSBhcm15IG9mZmljZXI%3D").place(x=400,y=700)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="agriculture officer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="hotel management":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="modeling":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="politician":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="psychologist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="journalist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="interior designer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="web designer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="event manager":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="professional artist":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="web designer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="event manager":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="full stack developer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
    elif GOAL.get().lower()=="animator":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="art designer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="pilot":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)

    elif GOAL.get().lower()=="chartered accountant":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="stack marketer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="investment banker":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="accountant":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        

    elif GOAL.get().lower()=="enterpreneur":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)
        Button(careerframe,text="<--BACK",font=('monoco',40),fg='white',bg='forestgreen',command=login).place(x=50,y=700)
        
        #email(sender_email, recipient_email, subject, body, im, smtp_server, smtp_port, smtp_username, smtp_password)
        Button(careerframe,text="Next-->",font=('monoco',40),fg='white',bg='forestgreen',command=nextframe).place(x=1000,y=700)
        
    elif GOAL.get().lower()=="insurance":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    elif GOAL.get().lower()=="navy officer":
        loginframe.place_forget()
        careerframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
        careerframe.place(x=100,y=10)
        Label(careerframe,text="YOUR CAREER PATH:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=50 )

        img=Image.open(r'D:/teacher.png')
        img_T=img.resize((700,700),Image.LANCZOS)
        img=ImageTk.PhotoImage(img_T)
        Label(careerframe,image=img).place(x=100,y=100)

        im=Image.open(r'D:\Screenshot (264).png')
        im_T=im.resize((650,550),Image.LANCZOS)
        im=ImageTk.PhotoImage(im_T)
        Label(careerframe,image=im).place(x=20,y=120)

    else:
        messagebox.showerror("Oops!","Enter Valid Details..")
welcome()
def chat():
    # global chatframe,query,q,T
    # query=StringVar()
    # careerframe.place_forget()
    # chatframe=Frame(root,background="antiquewhite3",width=1300,height=1200)
    # chatframe.place(x=100,y=10)
    # Label(chatframe,text="Enter your query:",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=20,y=100 )
    # Entry(chatframe,text=query,font=('monoco',30,'bold'),fg='black',bg="antiquewhite3").place(x=400,y=100 )
    # q=query.get()
    # # Button(chatframe,text="GET ANSWER",font=('monoco',30,'bold'),fg='black',bg="antiquewhite3",command=getans).place(x=500,y=400 )
    # # T = Text(root, height = 5, width = 52).place(x=100,y=300)
# Create label

    # l = Label(root, text = "Fact of the Day")

    # l.config(font =("Courier", 14)
 
# Create button for next text.
 
    # l.pack()
    # T.pack()
    # b1.pack()
    # b2.pack()
 
# Insert The Fact.
 
# tk.mainloop()
    print("Career Assistant: Hello! How can i assist you today")
    while True:
        q=input("You:")
        if q.lower() in ("you","tell me about you","who are you","tell me about you something"):
            print('''Hello I am the career assistant. I am here to assist you about your career, If you have any queries about your career please feel free to ask any queries''')
        elif q.lower() in ("hi","hello","hii","hloo"):
            print(" Hello! How can i assist you today")
        elif q.lower() in ("what is software","who is software","software","define software","software engineer"):
            print('''System software is a program designed to run a computer's hardware and applications and manage its resources, such as its memory, processors, and devices. It also provides a platform for running application software, and system software is typically bundled with a computer's operating system.''')
        elif q.lower() in ("how are you","how was your day"):
            print("I am good what about you")
        elif q.lower() in ("what are the subfields of software engineering","subfields of software engineering","software engineering subfields","subfields of software engineering"):
            print('''It was interesting reading the other two (as of this writing) answers. They give a different perspective than what I think of regarding subfields of software engineering. So what follows is my perspective which is more focused on application domains. I suggest reading the other answers to get these other perspectives. It just goes to show that there is more than one way to slice up software engineering.

Artificial Intelligence
Business and Finance
Analytics
Data mining
Decision support systems
Banking
Commerce
Trading
Compilers, Parsers
Communications and Networks
Protocols
Computer graphics and Image Processing
Cryptography
Cyber-security
Hacking
Counter-measures
Database
Embedded systems
Automotive software
Avionics software
Control Systems
Medical device software
Telephony
Telemetry
Computer Aided Design (CAD)
Games
Information systems
Logistics
Manufacturing
Computer Aided Manufacturing (CAM)
Distributed Control Systems (DCS)
Music
Music sequencers
Sound effects
Music synthesis
Numerical Analysis
Office applications
Word processors
Spreadsheets
Presentations
Operating systems
Robotics
Signal processing
Simulation
Testing
Visualization
Voting
World wide web
Client-side
Server-side
It should be noted that many of these sub-fields overlap. It should also be noted that there is no doubt that this list is incomplete.

''')
        
        elif q.lower() in ("minimum qualifications of software engineer","qualifications to become software engineer","qualification of a software engineer","qualifications of software engineer","qualifications of software","what is the qualifications of a software engineer","qualifications of software engineer","software engineer qualifications","qualifications of software engineer"):
            print('''Software engineer needs a minimum level of education to start their career. A Bachelor's degree in computer software engineering, computer science, or mathematics is the most common entry-level qualification. Pursuing a Master's degree can further enhance your skills and knowledge, but it is not mandatory.''')
        elif q.lower() in ("software engineer skills","skills of a software engineer","skills required to become software engineer","what are the skills required to become software engineer","software skills","top skills of software engineer","skills required to become software engineer","skills of software engineer"):
            print('''
Computer Programming and Coding. ...
Software Development. ...
Object-Oriented Design (OOD) ...
Software Testing and Debugging. ...
Problem Solving and Logical Thinking. ...
Written and Verbal Communication. ...
Teamwork. ...
Find a Home for Your Software Engineering Skills.
''')
        elif q.lower() in ("top most software companies","top software companies","top software companies in india"):
            print('''Accenture
Tata Consultancy Services
Capgemini
Amazon
Cognizant Technology Solutions
IBM
Tech Mahindra
Microsoft
HCLTech
Oracle
Amdocs
Google
Adobe
Flipkart
Infosys
LTI
Deloitte
SAP
Wipro
Apple
Cisco
Hexaware Technologies
Hyperlink InfoSystem
Mphasis
''')
        elif q.lower() in ("average salary of software engineer","minimum and maximum salary of software engineer","average salary of a software engineer in india","maximum salary of software engineer","minimum salary of software engineer"):
            print('''Software Engineer salary in India ranges between ₹ 2.8 Lakhs to ₹ 15.4 Lakhs with an average annual salary of ₹ 8.2 Lakhs. Salary estimates are based on 536.1k latest salaries received from Software Engineers.

''')
        elif q.lower() in ("top most colleges for cse","best colleges for cse","colleges for cse"):
            print('''IIIT-H | The International Institute of Information Technology - Hyderabad

Jawaharlal Nehru Technological University Hyderabad

University of Hyderabad

Osmania University

Nizam College

Chaitanya Bharathi Institute of Technology

Indian Institute of Technology Hyderabad

College of Engineering Osmania University

Vallurupalli Nageswara Rao Vignana Jyothi Institute of Engineering &Technology

National Institute of Pharmaceutical Education And Research (NIPER)

St. Ann's College For Women

NALSAR University of Law

Maulana Azad National Urdu University

National Institute of Agricultural Extension Management

Mahindra University

Jawaharlal Nehru Architecture and Fine Arts University

Muffakham Jah College of Engineering & Technology (MJCET)

Vardhaman College of Engineering

National Institute of Fashion Technology

Vignana Jyothi Institute Of Management

Stanley College of Engineering & Technology for Women

Mahatma Gandhi Institute of Technology (MGIT)

Hyderabad Institute of Technology and Management

Lords Institute of Engineering & Technology

St. Peter’s Engineering College

Methodist College of Engineering and Technology

Maturi Venkata Subba Rao Engineering College

Andhra Mahila Sabha School Of Informatics

MLR Institute of Technology

The ICFAI FOUNDATION FOR HIGHER EDUCATION

Anurag University, Hyderabad

St. Francis College For Women

AAR Mahaveer Engineering College

Institute of Management Technology Hyderabad

TKR College of Engineering & Technology

Vasavi College of Engineering

Gokaraju Rangaraju Institute of Engineering and Technology

Keshav Memorial Institute of Technology

Malla Reddy Institute Of Technology - MLTM

AV College of Arts, Science and Commerce

Vidya Jyothi Institute of Technology
''')
        elif q.lower() in ("qualifications of doctor","qualifications to become doctor","doctor qualifications"):
            print(''' To become a doctor, MBBS is the basic degree required. The course consists of nine semesters and one year of mandatory internships. The timeline of this MBBS course 5 and a ½ years (+ 1 year of internship) in total as a compulsory program. If a student secures the best grades in this he/she can get hold of a good career in medicine.
''')
        elif q.lower() in ("cost of becoming doctor","what is the cost of becoming doctor"):
            print('''MBBS courses from Government at cost range from Rs.25,000-75,000. The government only offers about 25,000 seats.

Private colleges cost around Rs. 15-40 lakhs for an MBBS course.

The Management quota seats will range in Rs. 55-80 lakhs.

Students need to prepare well before going through an entrance examination in any type of course to become an MBBS doctor.

''')
        elif q.lower() in ("average salary of doctor","minimum and maximum salary of doctor","maximum salary of doctor","minimum salary of doctor","average salary of doctor"):
            print('''The average salary for Doctor is ₹1,65,938 per month in the Hyderabad. The average additional cash compensation for a Doctor in the Hyderabad is ₹1,10,765, with a range from ₹36,124 - ₹1,80,000.
''')
        elif q.lower() in ("top medical colleges in india","top medical colleges","top colleges for mbbs","best mbbs colleges"):
            print('''Christian Medical College
Vellore

King George's Medical University
Lucknow

Stanford University
Stanford

Harvard University
Cambridge

Johns Hopkins University
Baltimore

Maulana Azad Medical College
New Delhi

All India Institute Of Medical Sciences

University of Cambridge
Cambridge

University of Oxford
Oxford

University of California, Los Angeles
Los Angeles

Imperial College London
London

University College London
London

St. John’s Medical College
Bengaluru

University College Of Medical Sciences
Dilshad Garden

Banaras Hindu University
Varanasi

Amrita Vishwa Vidyapeetham, Coimbatore campus
Coimbatore

KASTURBA MEDICAL COLLEGE
Manipal

Sri Ramachandra Institute of Higher Education and Research
Chennai

Madras Medical College
Chennai

Aligarh Muslim University
Aligarh

Vardhman Mahavir Medical College
New Delhi

JSS Medical College
Mysuru

All India Institute of Medical Sciences, Bhubaneswar

Jawaharlal Institute of Postgraduate Medical Education and Research
Puducherry

Dr. D. Y. Patil Vidyapeeth, Pune
Pune

All India Institute of Medical Sciences, Jodhpur

Dayanand Medical College

Kasturba Medical College
Mangaluru

Siksha 'O' Anusandhan
Bhubaneswar

Jamia Hamdard University
New Delhi

IPGME&R and SSKM Hospital

All India Institute of Medical Sciences Bhopal

All India Institute of Medical
''')
        elif q.lower() in ("what is the marks for neet qualification","what is the qualification marks of neet","qualification marks for neet","neet qualification marks"):
            print('''NEET Eligibility
The minimum marks required in the NEET 2023 for MBBS (Out of 720) to participate in the counselling process are mentioned below: 

Category

NEET 2023 Cut-off Score

NEET 2023 Cut-off Percentile

Unreserved (UR)

715 – 117

50th Percentile

Scheduled Tribes and Physically Handicapped (ST-PH)

104 – 93

40th Percentile

Other Backward Classes (OBC)

116 – 93

40th Percentile

EWS & PH/ UR

116 – 105

45th Percentile

Scheduled Tribes (ST)

116 – 93

40th Percentile

Scheduled Caste and Physically Handicapped (SC-PH)

104 – 93

40th Percentile

Scheduled Caste (SC) 

116 – 93

40th Percentile

Other Backward Classes & Physically Handicapped (OBC-PH)-104 – 93

40th Percentile

''')
        elif q.lower() in ("courses in mbbs","medical courses","diffrent courses in mbbs","mbbs courses"):
            print('''Physiology
Anesthesiology
Biochemistry
Dermatology
Forensic Medicine
Obstetrics and Gynecology
Ophthalmology
Paediatrics
Pathology
Psychiatry
Surgery
Community Medicine
ENT
Genetics
Medication
Microbiology
Orthopaedics
Pharmacology
Biophysics
Cardiology
Endocrinology
Haematology
''')
        elif q.lower() in ("tell me about mbbs","mbbs","give me full details about mbbs","how to become doctor"):
            print('''MBBS Full Form	Bachelor of Medicine and Bachelor of Surgery
MBBS Course Duration	5.5 years
MBBS Fees	Rs. 71,000 to Rs.2,100,000
Average Salary	Rs. 3,60,000 per annum
Career Opportunities	Physician, Doctor, Endocrinologist, Pathologist, Neurologist, Cardiologist, Gynaecologist
''')
        elif q.lower() in ("skills for ai engineer","skills required to become ai engineer","skills for ai engineer","what are the skills required to become ai engineer","skills for ai developer"):
            print('''Whether you’re looking for a new move in data science, or just retooling for your current role, Ben shows you the skill set that can set you apart, working down the list, one skill at a time. Explore the fundamentals of programming languages, machine learning, deep learning, data processing and analysis, natural language processing, computer vision, cloud computing, big data technologies, DevOps and AIOps, and communicative problem-solving. Discover the importance of preparing for tomorrow by learning impactful, new skills today.
''')    
        elif q.lower() in ("qualifications of ai engineer","ai engineer qualifications","qualifications required to become ai engineer"):
            print(''' Bachelor's degree in a field related to AI, such as data science, computer science, IT or statistics. Master's degree (though not typically required) in such disciplines as data science, mathematics, cognitive science or computer science. Enrollment in additional AI-related courses and certification programs 
''')
        elif q.lower() in ("average salary of ai engineer","ai engineer salary","salary of ai engineer in india","minimum and maximum salary of ai engineer"):
            print('''The average salary for AI Engineer is ₹9,98,359 per year in the India. The average additional cash compensation for a AI Engineer in the India is ₹98,359, with a range from ₹49,590 - ₹2,00,000.
''')
        elif q.lower() in ("top companies for ai engineers","companies for ai engineers to work"):
            print('''-TOPMOST COMPANIES FOR AI NGINEERS

Amazon

IBM

Google

Accenture

Dataiku

DataRobot

Microsoft

OpenAI

Salesforce

Dataminr

Nvidia

AlphaSense

Apple

Bosch

Databricks

DeepMind

Grammarly

Hyperlink InfoSystem
AIBrain
Capgemini
Copy.ai
C3 ai icon
First Student
HighRadius

--TOPMOST COLLEGES FOR AI ENGINEERS


Indian Institute of Technology Hyderabad

Indian Institute of Technology Bombay
Mumbai

Lovely Professional University
Phagwara

Indian Institute Of Technology–Madras (IIT–Madras)
Chennai

Indian Institute Of Technology Roorkee
Roorkee

Delhi Technological University
Rohini

Malaviya National Institute of Technology Jaipur (MNIT)
Jaipur

Chandigarh University
Sahibzada Ajit Singh Nagar

Jain (Deemed-to-be University)
Bengaluru

Carnegie Mellon University
Pittsburgh

Stanford University
Stanford

University of California, Berkeley
Berkeley

University of Washington
Seattle

Indraprastha Institute of Information Technology Delhi

University of Texas at Austin
Austin

Massachusetts Institute of Technology
Cambridge

Georgia Institute of Technology
Atlanta

Birla Institute of Technology And Science, Pilani (BITS Pilani)
Pilani

SRM Institute of Science and Technology
Chennai

UPES
Dehradun

SRM University (Sonepat, Haryana)

University of Illinois Urbana-Champaign
Champaign

Cornell University
Ithaca

University of Michigan
Ann Arbor

Anna University
Chennai

IIIT-H | The International Institute of Information Technology - Hyderabad
Hyderabad

D. Y. Patil International University

G. H. Raisoni College of Engineering
Nagpur

Indian Institute of Technology Guwahati
Guwahati

Vellore Institute of Technology
Vellore

SASTRA Deemed University
Thanjavur

Parul University

Indian Institute Of Technology Delhi (IIT Delhi)
New Delhi

Quantum University

Chandigarh Group of Colleges Jhanjeri Mohali

National Institute of Technology Karnataka (NITK) Surathkal.
Mangaluru

DIT University

SAGE University

JK Lakshmipat University
Jaipur

VIT Bhopal University

CT University Ludhiana - Best University in Punjab, India

Amity University Noida
Noida

Indian Institute of Technology (IIT), Jodhpur

Indian Institute Of Technology Gandhinagar (IIT Gandhinagar)
Ahmedabad

COEP Technological University
Pune''')
        elif q.lower() in ("how to become ias","how can i become ias"):
            print('''A candidate must have a graduate degree from any recognised university to become an IAS officer and pass the UPSC CSE exam.
This exam is open to candidates in their final year of graduation.
Candidates who have completed a correspondence education programme are also qualified to take this exam.
This examination is open to both professionals and non-professionals.
This examination is also open to medical students. But only if he has finished his degree and is currently enrolled in an internship programme.
Candidates who have passed the CA, ICWA, and ICSI exams are also eligible to apply.
''')
        elif q.lower() in ("qualification of ias","qualifications to become ias","qualifications for ias"):
            print('''Education Qualification for IAS exam: Candidate must hold a Graduate Degree from a recognised University. UPSC Civil Services Exam Age Limit: Candidate must be a minimum of 21 years of age and must not be more than 32 years of age.
''')
        elif q.lower() in ("average salary of ias","salary of ias","minimum and maximum salary of ias",'salary of ias in india'):
            print('''The basic salary of an entry-level IAS officer is 56,000 INR per month, and it varies with promotions. The take-home salary per month would be 56100+DA+House rent Allowance+ Transport Allowance. The maximum take-home salary is INR 2,50,000, and it is for the cabinet secretary.
''')
        elif q.lower() in ("topmost coaching centres for becoming ias","coaching centres to become ias","coaching centres of ias in india","coaching centres for ias"):
            print('''Vision IAS. ...
Vajiram and Ravi Coaching Centre for UPSC. ...
ForumIAS. ...
Shankar IAS Academy. ...
Insights IAS. ...
IASbaba. ...
Drishti IAS. ...
Byju's IAS. Byju's is a Bangalore-based EdTech firm that offers offline classroom coaching as well as a tablet program.
''')
        elif q.lower() in ("how to become an enterpreuner","how can i become an enterpreuner","enterpreuner"):
            print('''Build Your Skill Set and Knowledge Base. No matter what, you want to start and stay curious. ...
Build Your Network. No one ever succeeded alone. ...
State Your Idea, Claim Your Niche. ...
Find and Understand a Market. ...
Design Your Business and Idea. ...
Secure Finding. ...
Build Your Business.
''')
        elif q.lower() in ("top enterpreuner skills","skills of a enterpreneur","skills of enterpreneur",'entrepreneurial skills'):
            print('''Business Management Skills. ...
Communication and Listening. ...
Critical and Creative Thinking Skills. ...
Strategic Thinking and Planning Skills. ...
Branding, Marketing, and Networking Skills. ...
Entrepreneurial Skills in the Workplace. ...
Teamwork and Leadership Skills.
 ''')
        elif q.lower() in("enterpreneurship","what is enterpreneurship"):
            print('''Entrepreneurship is the creation or extraction of economic value in ways that generally entail beyond the minimal amount of risk (assumed by a traditional business), and potentially involving values besides simply economic ones.
''')
        elif q.lower() in ("minimum and maximum salary of enterpreneur","average salary of enterpreneur","income of enterpreneur","income of enterpreneur in india"):
            print('''The average entrepreneur salary in India is ₹ 1,150,000 per year or ₹ 461 per hour. Entry-level positions start at ₹ 405,000 per year, while most experienced workers make up to ₹ 2,000,000 per year.
''')
        elif q.lower() in ("how to become a lawyer","how to become lawyer",'how can i become lawyer'):
            print('''Complete 10+2 schooling. The first step is completing higher secondary education or 10+2 schooling in any stream - arts, science or commerce. ...
Obtain a bachelor's degree. ...
Complete LLB degree. ...
Enroll with Bar Council of India. ...
Appear for AIBE exam. ...
Consider higher law degrees. ...
Gain practical experience.
''')
        elif q.lower() in ("eligibility to become lawyer","qualifications of a lawyer","qualifications to become lawyer"):
            print('''They must sit for various national-level or University level entrance exams such as CLAT, AILET and LSAT. They must complete their 5 years Undergraduate course such as BA LLB, BCom LLB, BSc LLB. Students who have LLM degrees can also become a Lawyer.
''')
        elif q.lower() in ("average salary of lawyer in india","minimum and maximum salary of lawyer"):
            print('''With an average annual salary offered of Rs 4 to 6 lakhs per annum (LPA), these professionals are open to working in different industries like Law firms, Government Agencies, MNCs, Judicial Bodies, Banks, Litigation, etc.
''')
        elif q.lower() in ("skills for civil engineer","skills of civil engineer","civil engineer skills","what are skills required to become civil engineer","skills required to become civil engineer"):
            print('''
Communication skills
Critical thinking
Leadership
Problem solving
Project management
Organizational skills

Technical skills

Attention to detail

Decision making

Creativity

Teamwork

Time management

Construction knowledge

Maths knowledge

Negotiations

Writing skills

Adaptability

Budget management

Civil engineering basics technical skills

Delegation
Math skills
Analytical skills
Computer skills
Attention skills
''')
        elif q.lower() in ("how can i become civil engineer","how to become civil engineer","how i became civil engineer"):
            print('''Civil engineers typically need a bachelor's degree in civil engineering or a related field. Civil engineering programs include coursework in math, physics, engineering mechanics, and construction systems. Courses may include a mix of academic learning and laboratory work.
''')
        elif q.lower() in ("qualifications for civil engineer","what are the qualifications of civil engineer","qualifications to become civil engineer",'qualifications of a civil engineer'):
            print('''Degree – A KCSE mean grade of C plus or above plus the same grade in maths, physics, chemistry, and in either English or Kiswahili. Diploma – As mentioned earlier, the only requirement for a diploma in Civil engineering is a KCSE mean grade of C minus or above. Certificate – A mean grade of D Plus or above in KCSE.''')
        elif q.lower() in ("colleges for civil engineers","top colleges for civil engineer",'best colleges for civil engineering in india'):
            print('''IIT Madras

1

4.6

IIT Delhi

2

4.5

IIT Bombay

3

4.6

IIT Kanpur

4

4.7

IIT Kharagpur

5

4.5

IIT Roorkee

6

4.4

IIT Guwahati

7

4.4

IIT Hyderabad

8

4.6

NIT Trichy

9

4.3

IIT Indore

10

4.1

''')
        elif q.lower() in ("skills of a data scientist",'skills required to become data scientist','what are the skills required to become data scientist',"skills for a data scientist","skills of data scientist"):
            print('''The top three skills for a data scientist are strong programming knowledge (Python, R, etc.), expertise in machine learning, statistics, data analysis, and data visualization (using tools like Tableau or Power BI), and domain knowledge to understand and solve real-world problems effectively.
Ability to prepare data for effective analysis. With this skill, you will: ...
Ability to leverage self-service analytics platforms. ...
Ability to write efficient and maintainable code. ...
Ability to apply math and statistics appropriately. ...
Ability to leverage machine learning and artificial intelligence (AI)''')
        elif q.lower() in ("qualifications of data scientist","what are the qualifications required to become data scientist","qualifications for data scientist","data scientist qualifications"):
            print('''Data scientists typically need at least a bachelor's degree in computer science, data science, or a related field. However, many employers in this field prefer a master's degree in data science or a related discipline. Data analysts and data engineers usually need a bachelor's degree.
''')
        elif q.lower in ("average salary of data scientist","data scientist salary","salary of data scientist in india","salary of data scientist",'minimum and maximum salary of data scientist'):
                 print('''Data Scientist salary in India ranges between ₹ 3.9 Lakhs to ₹ 27.9 Lakhs with an average annual salary of ₹ 13.3 Lakhs. Salary estimates are based on 38.2k latest salaries received from Data Scientists.
''')
        elif q.lower() in ('top data science colleges in india',"top colleges for data scientist","best colleges for data science"):
            print('''Indian Institute of Technology (IIT), Madras
Indian Institute of Technology (IIT), Delhi
Indian Institute of Technology (IIT), Bombay
Indian Institute of Technology (IIT), Kanpur
Indian Institute of Technology (IIT), Kharagpur
Indian Institute of Technology (IIT), Roorkee
International Institute of Information Technology (IIIT), Hyderabad
National Institute of Technology, Warangal
Delhi Technological University (DTU), Delhi
Malaviya National Institute of Technology (MNIT), Jaipur
''')
        elif q.lower() in ("how to become a teacher","how can i become teacher","how to become teacher"):
            print('''One of the most important steps to becoming a teacher in India is to obtain a recognised degree. In addition to their undergraduate and graduate degrees in their subject of choice, teachers in the country must also complete a B.Ed. Students wanting to specialise and teach at higher levels can also obtain an M.Ed.

Candidates must take different National and State Level Teaching Entrance Exams, including SET, TET, NET and others in order to be qualified to teach in a variety of schools and colleges.
''')
        elif q.lower() in ("qualifications of a teacher","what are the qualifications required to become teacher",'qualifications required to become teacher',"qualifications for teacher"):
            print('''To become a government teacher, you may complete entrance examinations such as the Central Teacher Eligibility Test (CTET), National Eligibility Test (NET) or Teacher Eligibility Test (TET). After completing your 10+2 level, you then study for a 2-year bachelor's degree in education (B. Ed.).
''')
        elif q.lower() in ("average salary of teacher","average salary of teacher in india","minimum and maximum salary of teacher","salary of teacher in india","salary of a teacher"):
            print('''Teacher salary in India ranges between ₹ 0.3 Lakhs to ₹ 5.4 Lakhs with an average annual salary of ₹ 2.8 Lakhs. Salary estimates are based on 42.8k latest salaries received from Teachers.
''')
        elif q.lower() in ("average salary of civil engineer",'salary of civil engineer','salary of civil engineer in india','minimum and maximum salary of civil engineer'):
            print('''Civil Engineer salary in India ranges between ₹ 1.2 Lakhs to ₹ 7.1 Lakhs with an average annual salary of ₹ 4.6 Lakhs. Salary estimates are based on 38.6k latest salaries received from Civil Engineers.
''')
        else:
            print("Sorry! I am still under development. Now I dont have a answer on that particualr question.But in the future i will definitely give the answer to that particular question.")

root.mainloop()