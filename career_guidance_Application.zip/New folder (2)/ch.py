
print("Career Assistant: Hello! How can i assist you today")
while True:
        q=input("You:")
        if q.lower() in ("you","tell me about you","who are you","tell me about you something"):
            print('''Hello I am the career assistant. I am here to assist you about your career, If you have any queries about your career please feel free to ask any queries''')
        elif q.lower() in ("hi","hello","hii","hloo"):
            print(" Hello! How can i assist you today")
        elif q.lower() in ("how are you","how was your day"):
            print("I am good what about you")
        elif q.lower() in ("what are the subfields of software engineering","subfields of software engineering","software engineering subfields","subfields of software engineering"):
            print('''It was interesting reading the other two (as of this writing) answers. They give a different perspective than what I think of regarding subfields of software engineering. So what follows is my perspective which is more focused on application domains. I suggest reading the other answers to get these other perspectives. It just goes to show that there is more than one way to slice up software engineering.

Artificial Intelligence
Business and Finance
Analytics
Data mining
Decision support systems
Banking
Commerce
Trading
Compilers, Parsers
Communications and Networks
Protocols
Computer graphics and Image Processing
Cryptography
Cyber-security
Hacking
Counter-measures
Database
Embedded systems
Automotive software
Avionics software
Control Systems
Medical device software
Telephony
Telemetry
Computer Aided Design (CAD)
Games
Information systems
Logistics
Manufacturing
Computer Aided Manufacturing (CAM)
Distributed Control Systems (DCS)
Music
Music sequencers
Sound effects
Music synthesis
Numerical Analysis
Office applications
Word processors
Spreadsheets
Presentations
Operating systems
Robotics
Signal processing
Simulation
Testing
Visualization
Voting
World wide web
Client-side
Server-side
It should be noted that many of these sub-fields overlap. It should also be noted that there is no doubt that this list is incomplete.

''')
        
        elif q.lower() in ("minimum qualifications of software engineer","what is the qualifications of a software engineer","qualifications of software engineer","software engineer qualifications","qualifications of software engineer"):
            print('''Software engineer needs a minimum level of education to start their career. A Bachelor's degree in computer software engineering, computer science, or mathematics is the most common entry-level qualification. Pursuing a Master's degree can further enhance your skills and knowledge, but it is not mandatory.''')
        elif q.lower() in ("software engineer skills","skills of a software engineer","software skills","top skills of software engineer","skills required to become software engineer"):
            print('''
Computer Programming and Coding. ...
Software Development. ...
Object-Oriented Design (OOD) ...
Software Testing and Debugging. ...
Problem Solving and Logical Thinking. ...
Written and Verbal Communication. ...
Teamwork. ...
Find a Home for Your Software Engineering Skills.
''')
        elif q.lower() in ("top most software companies","top software companies","top software companies in india"):
            print('''Accenture
Tata Consultancy Services
Capgemini
Amazon
Cognizant Technology Solutions
IBM
Tech Mahindra
Microsoft
HCLTech
Oracle
Amdocs
Google
Adobe
Flipkart
Infosys
LTI
Deloitte
SAP
Wipro
Apple
Cisco
Hexaware Technologies
Hyperlink InfoSystem
Mphasis
''')
        elif q.lower() in ("average salary of software engineer","minimum and maximum salary of software engineer","average salary of a software engineer in india","maximum salary of software engineer","minimum salary of software engineer"):
            print('''Software Engineer salary in India ranges between ₹ 2.8 Lakhs to ₹ 15.4 Lakhs with an average annual salary of ₹ 8.2 Lakhs. Salary estimates are based on 536.1k latest salaries received from Software Engineers.

''')
        elif q.lower() in ("top most colleges for cse","best colleges for cse","colleges for cse"):
            print('''IIIT-H | The International Institute of Information Technology - Hyderabad

Jawaharlal Nehru Technological University Hyderabad

University of Hyderabad

Osmania University

Nizam College

Chaitanya Bharathi Institute of Technology

Indian Institute of Technology Hyderabad

College of Engineering Osmania University

Vallurupalli Nageswara Rao Vignana Jyothi Institute of Engineering &Technology

National Institute of Pharmaceutical Education And Research (NIPER)

St. Ann's College For Women

NALSAR University of Law

Maulana Azad National Urdu University

National Institute of Agricultural Extension Management

Mahindra University

Jawaharlal Nehru Architecture and Fine Arts University

Muffakham Jah College of Engineering & Technology (MJCET)

Vardhaman College of Engineering

National Institute of Fashion Technology

Vignana Jyothi Institute Of Management

Stanley College of Engineering & Technology for Women

Mahatma Gandhi Institute of Technology (MGIT)

Hyderabad Institute of Technology and Management

Lords Institute of Engineering & Technology

St. Peter’s Engineering College

Methodist College of Engineering and Technology

Maturi Venkata Subba Rao Engineering College

Andhra Mahila Sabha School Of Informatics

MLR Institute of Technology

The ICFAI FOUNDATION FOR HIGHER EDUCATION

Anurag University, Hyderabad

St. Francis College For Women

AAR Mahaveer Engineering College

Institute of Management Technology Hyderabad

TKR College of Engineering & Technology

Vasavi College of Engineering

Gokaraju Rangaraju Institute of Engineering and Technology

Keshav Memorial Institute of Technology

Malla Reddy Institute Of Technology - MLTM

AV College of Arts, Science and Commerce

Vidya Jyothi Institute of Technology
''')
        elif q.lower() in ("qualifications of doctor","qualifications to become doctor","doctor qualifications"):
            print(''' To become a doctor, MBBS is the basic degree required. The course consists of nine semesters and one year of mandatory internships. The timeline of this MBBS course 5 and a ½ years (+ 1 year of internship) in total as a compulsory program. If a student secures the best grades in this he/she can get hold of a good career in medicine.
''')
        elif q.lower() in ("cost of becoming doctor","what is the cost of becoming doctor"):
            print('''MBBS courses from Government at cost range from Rs.25,000-75,000. The government only offers about 25,000 seats.

Private colleges cost around Rs. 15-40 lakhs for an MBBS course.

The Management quota seats will range in Rs. 55-80 lakhs.

Students need to prepare well before going through an entrance examination in any type of course to become an MBBS doctor.

''')
        elif q.lower() in ("average salary of doctor","minimum and maximum salary of doctor","maximum salary of doctor","minimum salary of doctor","average salary of doctor"):
            print('''The average salary for Doctor is ₹1,65,938 per month in the Hyderabad. The average additional cash compensation for a Doctor in the Hyderabad is ₹1,10,765, with a range from ₹36,124 - ₹1,80,000.
''')
        elif q.lower() in ("top medical colleges in india","top medical colleges","top colleges for mbbs","best mbbs colleges"):
            print('''Christian Medical College
Vellore

King George's Medical University
Lucknow

Stanford University
Stanford

Harvard University
Cambridge

Johns Hopkins University
Baltimore

Maulana Azad Medical College
New Delhi

All India Institute Of Medical Sciences

University of Cambridge
Cambridge

University of Oxford
Oxford

University of California, Los Angeles
Los Angeles

Imperial College London
London

University College London
London

St. John’s Medical College
Bengaluru

University College Of Medical Sciences
Dilshad Garden

Banaras Hindu University
Varanasi

Amrita Vishwa Vidyapeetham, Coimbatore campus
Coimbatore

KASTURBA MEDICAL COLLEGE
Manipal

Sri Ramachandra Institute of Higher Education and Research
Chennai

Madras Medical College
Chennai

Aligarh Muslim University
Aligarh

Vardhman Mahavir Medical College
New Delhi

JSS Medical College
Mysuru

All India Institute of Medical Sciences, Bhubaneswar

Jawaharlal Institute of Postgraduate Medical Education and Research
Puducherry

Dr. D. Y. Patil Vidyapeeth, Pune
Pune

All India Institute of Medical Sciences, Jodhpur''')
